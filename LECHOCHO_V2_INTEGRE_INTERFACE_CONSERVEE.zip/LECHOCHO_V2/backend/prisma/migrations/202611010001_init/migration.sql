CREATE TYPE "UserRole" AS ENUM ('BUYER', 'SELLER', 'DEALER', 'ADMIN');
CREATE TYPE "ListingStatus" AS ENUM ('PENDING', 'PUBLISHED', 'REJECTED', 'ARCHIVED');
CREATE TYPE "OrderStatus" AS ENUM ('ACTIVE', 'CONTACT_UNLOCKED', 'CLOSED');
CREATE TYPE "ContactUnlockStatus" AS ENUM ('NOT_REQUESTED', 'PENDING', 'PAID', 'FAILED');

CREATE TABLE "User" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "phone" TEXT NOT NULL,
  "email" TEXT,
  "passwordHash" TEXT NOT NULL,
  "role" "UserRole" NOT NULL DEFAULT 'BUYER',
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "Listing" (
  "id" TEXT NOT NULL,
  "sellerId" TEXT NOT NULL,
  "brand" TEXT NOT NULL,
  "model" TEXT NOT NULL,
  "year" INTEGER NOT NULL,
  "priceXaf" INTEGER NOT NULL,
  "city" TEXT NOT NULL,
  "fuel" TEXT,
  "gearbox" TEXT,
  "mileageKm" INTEGER,
  "description" TEXT,
  "imageUrl" TEXT,
  "premium" BOOLEAN NOT NULL DEFAULT false,
  "status" "ListingStatus" NOT NULL DEFAULT 'PENDING',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Listing_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "VehicleOrder" (
  "id" TEXT NOT NULL,
  "requesterId" TEXT,
  "requesterName" TEXT NOT NULL,
  "requesterPhone" TEXT NOT NULL,
  "brand" TEXT,
  "model" TEXT,
  "minYear" INTEGER,
  "maxBudgetXaf" INTEGER,
  "city" TEXT NOT NULL,
  "details" TEXT,
  "status" "OrderStatus" NOT NULL DEFAULT 'ACTIVE',
  "contactUnlock" "ContactUnlockStatus" NOT NULL DEFAULT 'NOT_REQUESTED',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "VehicleOrder_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "AuditLog" (
  "id" TEXT NOT NULL,
  "actorId" TEXT,
  "action" TEXT NOT NULL,
  "entity" TEXT NOT NULL,
  "entityId" TEXT NOT NULL,
  "metadata" JSONB,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "AuditLog_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "User_phone_key" ON "User"("phone");
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");
CREATE INDEX "User_role_active_idx" ON "User"("role", "active");
CREATE INDEX "Listing_status_premium_createdAt_idx" ON "Listing"("status", "premium", "createdAt");
CREATE INDEX "Listing_brand_model_city_idx" ON "Listing"("brand", "model", "city");
CREATE INDEX "VehicleOrder_status_createdAt_idx" ON "VehicleOrder"("status", "createdAt");
CREATE INDEX "VehicleOrder_city_brand_model_idx" ON "VehicleOrder"("city", "brand", "model");
CREATE INDEX "AuditLog_entity_entityId_idx" ON "AuditLog"("entity", "entityId");
ALTER TABLE "Listing" ADD CONSTRAINT "Listing_sellerId_fkey" FOREIGN KEY ("sellerId") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "VehicleOrder" ADD CONSTRAINT "VehicleOrder_requesterId_fkey" FOREIGN KEY ("requesterId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
