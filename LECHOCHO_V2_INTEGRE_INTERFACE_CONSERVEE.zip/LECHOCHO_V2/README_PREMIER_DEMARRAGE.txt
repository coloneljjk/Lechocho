LECHOCHO V2 — INTERFACE CONSERVEE + BACKEND EN PREPARATION

IMPORTANT : cette livraison conserve le frontend V2 (index.html, admin.html, assets, logo et styles). Le dossier backend est séparé et ne remplace pas l’interface.

TESTER IMMEDIATEMENT :
1. Extraire tout le ZIP.
2. Ouvrir index.html à la racine du dossier LECHOCHO_V2.
3. Ne pas ouvrir backend/ pour afficher le site.
4. Pour le tableau d’administration local, ouvrir admin.html.

ETAT : le site V2 fonctionne localement avec données de démonstration. Le backend Express/PostgreSQL est un socle de code, non déployé et non raccordé au frontend. Ne pas utiliser en production avant installation, tests API/DB et connexion du frontend.

PRESERVATION : logo, palette noir/blanc/rouge, interface FR/EN, responsive mobile et parcours V2 conservés.
