# LECHOCHO API — fondation backend (0.1)

Backend initial de la marketplace LECHOCHO exploitée par Global Services. Il est volontairement séparé du front V2 : le front actuel reste une démonstration locale tant que l'intégration API n'est pas réalisée.

## Stack
- Node.js 20+
- Express 5
- PostgreSQL + Prisma
- JWT + bcrypt (authentification serveur)
- Zod (validation), Helmet, CORS et limitation des tentatives de connexion

## Installation locale
1. Installer Node.js 20+ et PostgreSQL.
2. Copier `.env.example` vers `.env` puis configurer `DATABASE_URL`, `JWT_SECRET` (32 caractères minimum), `FRONTEND_ORIGIN`, `ADMIN_PHONE` et `ADMIN_PASSWORD` (12 caractères minimum).
3. Dans `backend/` : `npm install`
4. `npx prisma generate`
5. `npx prisma db push` (initialisation de la base de développement)
6. `npm run seed` (création du compte administrateur)
7. `npm run dev`
8. Vérifier `GET http://localhost:4000/api/health`.

## Routes disponibles
- `POST /api/auth/register` — inscription avec téléphone + mot de passe (10 caractères minimum).
- `POST /api/auth/login` — connexion réelle avec mot de passe.
- `GET /api/auth/me` — session via `Authorization: Bearer <token>`.
- `GET /api/listings` — annonces publiées uniquement, filtres `q`, `city`, `brand`, `maxPrice`.
- `POST /api/listings` — dépôt authentifié par vendeur/concessionnaire/admin ; annonce en attente de modération.
- `GET /api/listings/mine` — annonces de l'utilisateur connecté.
- `POST /api/orders` — demande publique sans inscription ; téléphone conservé côté serveur et jamais inclus dans la réponse publique.
- `GET /api/orders/public` — demandes actives sans coordonnées privées.
- `GET /api/orders/admin` — toutes les demandes pour administrateur.
- `GET /api/admin/overview`, `/listings`, `/users` — administration.
- `PATCH /api/admin/listings/:id/status` — modération.
- `PATCH /api/admin/listings/:id/premium` — gestion Premium.

## Rôles
`BUYER`, `SELLER`, `DEALER`, `ADMIN`. L'inscription publique crée un rôle `BUYER`. La promotion en vendeur/concessionnaire doit être une action contrôlée par l'administration (à développer dans l'interface admin).

## Sécurité et limites de cette fondation
- Les mots de passe sont hachés avec bcrypt ; aucun mot de passe n'est renvoyé par l'API.
- Les jetons sont signés avec un secret d'environnement ; ne jamais publier `.env`.
- Les commandes publiques n'exposent pas le téléphone. La route admin est réservée au rôle `ADMIN`.
- Cette version n'intègre pas encore OTP/SMS, récupération de compte, stockage objet durable des images, notifications, paiement, webhook de paiement, ni journalisation complète de toutes les opérations.
- Les photos ne doivent pas être téléversées sur le serveur public avant d'avoir ajouté un endpoint d'upload contrôlé et une politique de stockage/suppression.
- Prévoir HTTPS, sauvegardes PostgreSQL, politique de confidentialité, conditions d'utilisation, anti-spam et revue de sécurité avant mise en production.

## Intégration frontend
Le front V2 utilise actuellement `localStorage`. Il ne bascule pas automatiquement sur cette API. Une étape d'intégration dédiée doit remplacer les lectures/écritures locales par `fetch` avec gestion des erreurs, état de chargement et fallback explicitement marqué démo. Les demandes publiques peuvent être connectées en premier, puis annonces, comptes et administration. Ne pas supprimer le mode démo avant tests de bout en bout.

## Paiements
Aucune route de paiement n'est présente volontairement. L'intégration ultérieure devra utiliser les API officielles d'un agrégateur ou opérateur, vérifier les webhooks côté serveur et ne jamais débloquer un téléphone sur la seule base d'une redirection navigateur.
