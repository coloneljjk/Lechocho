require('dotenv').config();
const express=require('express');const cors=require('cors');const helmet=require('helmet');const rateLimit=require('express-rate-limit');const path=require('path');const fs=require('fs');const prisma=require('./prisma');
const app=express();const port=Number(process.env.PORT||4000);
if(!process.env.JWT_SECRET||process.env.JWT_SECRET.length<32){console.error('JWT_SECRET doit contenir au moins 32 caractères.');process.exit(1)}
app.use(helmet());app.use(cors({origin:(process.env.FRONTEND_ORIGIN||'http://localhost:5500').split(',').map(s=>s.trim()),credentials:false}));app.use(express.json({limit:'1mb'}));
app.use('/api/auth',rateLimit({windowMs:15*60*1000,limit:30,standardHeaders:true,legacyHeaders:false}));
app.get('/api/health',async(_req,res)=>{try{await prisma.$queryRaw`SELECT 1`;res.json({status:'ok',service:'LECHOCHO API',database:'connected'});}catch{res.status(503).json({status:'degraded',service:'LECHOCHO API',database:'unavailable'});}});
app.use('/api/auth',require('./routes/auth'));app.use('/api/listings',require('./routes/listings'));app.use('/api/orders',require('./routes/orders'));app.use('/api/admin',require('./routes/admin'));
app.use((err,req,res,_next)=>{if(err.name==='ZodError')return res.status(400).json({error:'Données invalides.',details:err.issues.map(x=>({field:x.path.join('.'),message:x.message}))});console.error(err);res.status(500).json({error:'Erreur serveur.'});});
const uploads=path.resolve(process.env.UPLOAD_DIR||'uploads');fs.mkdirSync(uploads,{recursive:true});app.use('/uploads',express.static(uploads,{fallthrough:false,maxAge:'1d'}));
const server=app.listen(port,()=>console.log(`LECHOCHO API listening on :${port}`));
async function shutdown(){server.close();await prisma.$disconnect();process.exit(0)}process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
