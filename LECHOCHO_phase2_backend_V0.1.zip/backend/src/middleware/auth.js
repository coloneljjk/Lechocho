const jwt = require('jsonwebtoken');
const prisma = require('../prisma');

async function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Authentification requise.' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await prisma.user.findUnique({ where: { id: payload.sub }, select: { id:true, name:true, phone:true, email:true, role:true, active:true } });
    if (!user || !user.active) return res.status(401).json({ error: 'Session invalide.' });
    req.user = user;
    next();
  } catch { return res.status(401).json({ error: 'Jeton invalide ou expiré.' }); }
}
function requireRole(...roles) { return (req,res,next) => roles.includes(req.user?.role) ? next() : res.status(403).json({error:'Accès interdit.'}); }
module.exports = { authenticate, requireRole };
