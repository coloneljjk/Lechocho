const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const prisma = require('../prisma');
const { authenticate } = require('../middleware/auth');
const phoneSchema = z.string().trim().regex(/^\+?[0-9\s()-]{8,20}$/);
const registerSchema = z.object({ name:z.string().trim().min(2).max(100), phone:phoneSchema, email:z.string().email().optional().or(z.literal('')), password:z.string().min(10).max(100) });
const loginSchema = z.object({ phone:phoneSchema, password:z.string().min(1).max(100) });
function issue(user) { return jwt.sign({ sub:user.id }, process.env.JWT_SECRET, { expiresIn:process.env.JWT_EXPIRES_IN || '7d' }); }
router.post('/register', async (req,res,next) => { try {
  const data=registerSchema.parse(req.body); const phone=data.phone.replace(/[\s()-]/g,'');
  const exists=await prisma.user.findFirst({where:{OR:[{phone},{...(data.email?{email:data.email.toLowerCase()}:{email:'__never__'})}]}});
  if(exists) return res.status(409).json({error:'Ce téléphone ou cet e-mail est déjà utilisé.'});
  const passwordHash=await bcrypt.hash(data.password,12);
  const user=await prisma.user.create({data:{name:data.name,phone,email:data.email?data.email.toLowerCase():null,passwordHash},select:{id:true,name:true,phone:true,email:true,role:true}});
  res.status(201).json({user,token:issue(user)});
} catch(e){next(e)} });
router.post('/login', async (req,res,next) => { try {
  const data=loginSchema.parse(req.body); const phone=data.phone.replace(/[\s()-]/g,'');
  const user=await prisma.user.findUnique({where:{phone}});
  if(!user || !user.active || !(await bcrypt.compare(data.password,user.passwordHash))) return res.status(401).json({error:'Téléphone ou mot de passe incorrect.'});
  const safe={id:user.id,name:user.name,phone:user.phone,email:user.email,role:user.role}; res.json({user:safe,token:issue(safe)});
} catch(e){next(e)} });
router.get('/me',authenticate,(req,res)=>res.json({user:req.user}));
module.exports=router;
