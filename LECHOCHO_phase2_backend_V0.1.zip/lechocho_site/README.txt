LECHOCHO — FRONT-END V2
Exploitant prévu : Global Services
Cible : marketplace automobile au Cameroun

OUVRIR LE PROJET
1. Extraire le dossier lechocho_site.
2. Garder index.html et le dossier assets ensemble.
3. Ouvrir index.html dans un navigateur récent.
4. Pour l'administration, ouvrir admin.html ou cliquer sur « Administration (démo) » dans la navigation.

PARCOURS DISPONIBLES DANS CETTE VERSION
- Accueil noir, blanc et rouge, logo LECHOCHO conservé.
- Interface français / anglais et navigation responsive mobile.
- Recherche principale placée en haut : marque/modèle, ville, prix maximum.
- Champ de ville libre avec suggestions de villes dans les dix régions du Cameroun ; toute autre localité peut aussi être saisie.
- Rubrique « Commandes des clients » : cartes cliquables, détails au clic, téléphone masqué à l'écran.
- Véhicules Premium et véhicules standards, avec une seule action « Voir détails » sur chaque carte.
- Dépôt d'annonce et demande de commande : les formulaires restent fermés à l'ouverture et s'affichent uniquement après clic sur leur bouton.
- Demande de commande sans inscription ni e-mail.
- Ajout d'une photo principale à une annonce (compression locale dans le navigateur).
- Inscription / connexion de démonstration par téléphone avec code fixe 123456 ; aucun SMS n'est envoyé.
- Concessionnaires : vitrine informative et parcours de compte de démonstration.
- Administration locale : validation / refus d'annonces, retrait, passage en Premium, consultation des commandes et comptes de démonstration.

CE QUI FONCTIONNE RÉELLEMENT DANS LE NAVIGATEUR
- Recherche et filtrage local des véhicules de démonstration et des annonces approuvées localement.
- Ouverture des détails de véhicules et de demandes.
- Ouverture / fermeture des formulaires, validations de champs et compression locale d'une photo.
- Enregistrement local des annonces, commandes, comptes et session dans localStorage.
- Modération locale des annonces et rafraîchissement des listes.

LIMITES — AUCUN BACKEND CONNECTÉ
- Les annonces, demandes et comptes restent sur le navigateur et l'appareil utilisés. Ils ne sont pas transmis à Global Services et ne sont pas partagés entre visiteurs.
- L'inscription / connexion est une simulation locale, sans authentification serveur, SMS ou vérification d'identité.
- Le téléphone est masqué dans l'interface publique, mais la protection réelle des coordonnées exige un serveur et des règles d'accès. Ne pas saisir de vraies données confidentielles dans cette démo.
- Aucun paiement Mobile Money, carte bancaire ou déblocage automatique n'est activé. Les boutons de déblocage sont volontairement désactivés.
- L'administration locale n'est pas sécurisée et ne doit pas être utilisée pour une exploitation réelle.
- Les véhicules et demandes préchargés sont fictifs et identifiés comme démonstrations.

PROCHAINES ÉTAPES TECHNIQUES
1. Choisir et déployer le backend + base de données.
2. Créer les rôles et l'authentification sécurisée (vendeur, acheteur, concessionnaire, administrateur).
3. Mettre en place l'upload serveur des photos et la modération centralisée.
4. Connecter les notifications et les demandes à Global Services.
5. Intégrer plus tard les API de paiement Mobile Money / carte, puis le déblocage du contact uniquement après confirmation serveur du paiement.
6. Ajouter pages légales, politique de confidentialité, conditions d'utilisation et sécurisation anti-abus.

Aucune clé API, aucun identifiant bancaire et aucun numéro Mobile Money n'est nécessaire pour tester cette V2.
